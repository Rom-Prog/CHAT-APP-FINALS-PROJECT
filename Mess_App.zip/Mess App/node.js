const express = require('express');
const http = require('http');
const WebSocket = require('ws');

const app = express();
const server = http.createServer(app);
const wsServer = new WebSocket.Server({ server });

const userTopics = new Map();

wsServer.on("connection", (conn) => {
    conn.on("message", (message) => {
        const received = JSON.parse(message);
        if (received.topic) {
            userTopics.set(conn, received.topic);
        }
        const reply = {
            user: received.user,
            message: received.data,
            topic: received.topic
        };
        wsServer.clients.forEach((client) => {
            if (client.readyState === WebSocket.OPEN) {
                const clientTopic = userTopics.get(client);
                if (clientTopic === received.topic) {
                    client.send(JSON.stringify(reply));
                }
            }
        });
    });
});

server.listen(8080, () => {
    console.log("Server currently listens to port 8080");
});
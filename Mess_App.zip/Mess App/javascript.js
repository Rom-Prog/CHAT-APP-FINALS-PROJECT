const conn = new WebSocket('ws://localhost:8080');
const chatBox = document.getElementById("messages");
let user;
let selectedTopic;

// Function to fetch emojis from the API
async function fetchEmojis() {
    try {
        const response = await fetch('https://emoji-api.com/emojis?access_key=ada9326a6f72ee1256bb5f3cd5d80ef2d696dd8f');
        const emojis = await response.json();
        return emojis;
    } catch (error) {
        console.error('Error fetching emojis:', error);
        return [];
    }
}

// Function to display all emojis in the chat-box div
async function displayEmojis() {
    const emojiContainer = document.getElementById("emojiContainer");
    emojiContainer.innerHTML = ""; // Clear previous emojis

    // Call fetchEmojis function to get emojis
    const emojis = await fetchEmojis();
    emojis.forEach(emoji => {
        const emojiSpan = document.createElement("span");
        emojiSpan.innerHTML = emoji.character;
        emojiSpan.classList.add("emoji");
        // Add click event listener to send the emoji when clicked
        emojiSpan.addEventListener("click", () => {
            const messageInput = document.getElementById("messageInput");
            messageInput.value += emoji.character; // Append emoji to message input
        });
        emojiContainer.appendChild(emojiSpan);
    });

    // Show emoji container
    emojiContainer.style.display = "block";
}

// Hide emoji container when clicking outside of it
document.addEventListener("click", function(event) {
    const emojiContainer = document.getElementById("emojiContainer");
    if (!emojiContainer.contains(event.target)) {
        emojiContainer.style.display = "none";
    }
});

// Close emoji container when pressing ESC key
document.addEventListener("keydown", function(event) {
    if (event.key === "Escape") {
        const emojiContainer = document.getElementById("emojiContainer");
        emojiContainer.style.display = "none";
    }
});

conn.addEventListener("message", (message) => {
    const data = JSON.parse(message.data);
    if (!selectedTopic || data.topic === selectedTopic) {
        const item = document.createElement("div");
        item.appendChild(document.createTextNode(data.user + ": " + data.message));
        chatBox.appendChild(item);
    }
});

function login() {
    const usernameInput = document.getElementById("username");
    user = usernameInput.value.trim();

    if (user === "") {
        alert("Please enter your name.");
        return;
    }

    const loginDiv = document.getElementById("login");
    const chatDiv = document.getElementById("chat");

    loginDiv.style.display = "none";
    chatDiv.style.display = "flex";
}

function sendMessage() {
    const messageInput = document.getElementById("messageInput");
    if (!selectedTopic) {
        alert("Please select a topic first.");
        return;
    }
    if (messageInput.value == '') {
        alert("You can't send an empty message");
        return;
    }
    const message = JSON.stringify({
        user: user,
        data: messageInput.value,
        topic: selectedTopic
    });
    conn.send(message);
    messageInput.value = "";
}

function selectTopic(topic) {
    if (selectedTopic === topic) {
        alert("You are currently in the same topic that you selected");
        return;
    }

    selectedTopic = topic;
    document.getElementById("messages").innerHTML = "";
    const joinMessage = JSON.stringify({
        user: user,
        data: "joined the topic: " + selectedTopic,
        topic: selectedTopic
    });
    conn.send(joinMessage);
}

async function fetchGifs(query = 'funny') {
    try {
        const response = await fetch(`https://api.giphy.com/v1/gifs/search?api_key=83ZRVP6AeHvX77D7PWEeZGGAFmEtRwfi&limit=10&q=${query}`);
        const gifs = await response.json();
        return gifs.data; // Return the array of GIF data
    } catch (error) {
        console.error('Error fetching gifs:', error);
        return [];
    }
}


// Function to display all GIFs in the gifsContainer div
async function displayGifs() {
    const gifsContainer = document.getElementById("gifsContainer");
    gifsContainer.innerHTML = ""; // Clear previous GIFs

    // Call fetchGifs function to get GIFs
    const gifs = await fetchGifs();
    gifs.forEach(gif => {
        const gifImg = document.createElement("img");
        gifImg.src = gif.images.fixed_height.url; // Use the fixed_height image URL
        gifImg.classList.add("gif");
        // Add click event listener to send the GIF URL when clicked
        gifImg.addEventListener("click", () => {
            const messageInput = document.getElementById("messageInput");
            messageInput.value += gif.images.fixed_height.url; // Append GIF URL to message input
        });
        gifsContainer.appendChild(gifImg);
    });

    // Show GIF container
    gifsContainer.style.display = "block";
}

// Hide GIF container when clicking outside of it
document.addEventListener("click", function(event) {
    const gifsContainer = document.getElementById("gifsContainer");
    if (!gifsContainer.contains(event.target)) {
        gifsContainer.style.display = "none";
    }
});

// Close GIF container when pressing ESC key
document.addEventListener("keydown", function(event) {
    if (event.key === "Escape") {
        const gifsContainer = document.getElementById("gifsContainer");
        gifsContainer.style.display = "none";
    }
});

function displayAddTopicForm() {
    document.getElementById("addTopicForm").style.display = "block";
}

function addTopic() {
    const newTopicInput = document.getElementById("newTopicInput");
    const newTopic = newTopicInput.value.trim();

    if (newTopic === "") {
        alert("Please enter a topic name.");
        return;
    }

    const topicsDiv = document.getElementById("topics");
    const newTopicButton = document.createElement("button");
    newTopicButton.textContent = newTopic;
    newTopicButton.onclick = () => selectTopic(newTopic);
    topicsDiv.insertBefore(newTopicButton, document.getElementById("addTopicButton"));

    newTopicInput.value = "";
    document.getElementById("addTopicForm").style.display = "none";
}

document.getElementById('darkmode-toggle').addEventListener('change', function() {
    if (this.checked) {
        document.documentElement.setAttribute('data-theme', 'dark');
    } else {
        document.documentElement.removeAttribute('data-theme');
    }
});
document.body.style.backgroundImage = "url('light_bg.jpg')";
document.getElementById('darkmode-toggle').addEventListener('change', function() {
    const isChecked = this.checked;
    if (isChecked) {
        document.documentElement.setAttribute('data-theme', 'dark');
        document.body.style.backgroundImage = "url('dark_bg.jpg')";
    } else {
        document.documentElement.removeAttribute('data-theme');
        document.body.style.backgroundImage = "url('light_bg.jpg')";
    }
});
